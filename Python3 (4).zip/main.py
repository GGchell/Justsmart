import random
even_count = 0
odd_count = 0
while True:
    number = random.randint(1, 100)
    if number % 2 == 0:
        even_count += 1
    else:
        odd_count += 1
    if number == 100:
        break
print(f"Кількість парних чисел: {even_count}")
print(f"Кількість непарних чисел: {odd_count}")